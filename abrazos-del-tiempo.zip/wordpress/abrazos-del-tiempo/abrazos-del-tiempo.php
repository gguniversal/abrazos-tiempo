<?php
/**
 * Plugin Name: Abrazos del Tiempo
 * Description: Un plugin para generar imágenes con IA.
 * Version: 1.0
 * Author: Tu Nombre
 */

if (!defined('ABSPATH')) {
    exit;
}

include_once plugin_dir_path(__FILE__) . 'includes/api.php';
include_once plugin_dir_path(__FILE__) . 'includes/shortcode.php';
